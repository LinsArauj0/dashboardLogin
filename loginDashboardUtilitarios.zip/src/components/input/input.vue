<template>
    <div class="div-input">
        <label :for="id">{{ label }}</label>
        <input :type="type" :id="id" v-model="model" :placeholder="placeholder" @input="updateInput" />
        <small v-if="errorMessage" class="error-message">{{ errorMessage }}</small>
    </div>
</template>

<script>
import Password from 'primevue/password';

export default {
    name: 'InputForm',
    props: {
        id: {
            type: String,
            required: true
        },
        label: {
            type: String,
            default: ''
        },
        type: {
            type: [String, Password],
            default: ''
        },
        value: {
            type: [String, Number],
            default: ''
        },
        placeholder: {
            type: String,
            default: ''
        },
        errorMessage: {
            type: String,
            default: ''
        }
    },
    computed: {
        model: {
            get() {
                return this.value;
            },
            set(newValue) {
                this.$emit('input', newValue);
            }
        }
    },
    methods: {
        updateInput(event) {
            this.$emit('input', event.target.value);
        }
    }
}
</script>

<style>
@import './input.css';
</style>