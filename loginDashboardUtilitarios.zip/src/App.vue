<template>
  <div>
    
    <NavBar v-if="!isLoginRouter()"/>
  
    <RouterView />

  </div>
</template>

<script>
import NavBar from './components/NavBar/Navbar.vue';
  export default {
    name: 'App',
    components: {
      NavBar,
    },
    methods:{
      isLoginRouter(){
        return this.$route.name === 'Login'
      }
    }
  }
</script>

<style>
@import './App.css';
@import './bootstrap.css';
</style>