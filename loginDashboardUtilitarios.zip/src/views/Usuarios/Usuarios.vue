<template>
  <div id="main-user">
    <div class="user" @click="visible = true">
      <button>
        <img src="../../icons/button-user.png" />
      </button>
    </div>
    <div v-if="!users.length" class="no-results">
      <div>
        <img src="../../icons/No-results-found.png" alt="no results found" />
      </div>
      <span>Não há usuários. Clique no ícone acima para adicionar</span>
    </div>
    <DialogBox v-model:visible="visible" modal class="col-11 col-md-11 col-lg-7">
      <template #header>
        <span>Novo Usuário</span>
        <span>Novo Usuário</span>
      </template>
      <form class="col-lg-12" @submit.prevent="saveUser">
        <div class="d-flex row p-3">
          <div class="info">
            <span>Dados Básicos</span>
          </div>
          <div class="d-flex row">
            <div class="user-avatar col-12 col-md-12 col-lg-4">
              <img />
              <i class="bi bi-camera"> </i>
            </div>
            <div class="row col-12 col-md-12 col-lg-8">
              <InputForm :label="'Nome'" type="text" />
              <InputForm :label="'Nome da Mãe'" type="text" />
              <InputForm :label="'Nome do Pai'" type="text" />
            </div>
          </div>
          <div class="d-flex row col-12 col-md-12 col-lg-12">
            <InputForm class="col-12 col-lg-3" :label="'CPF'" type="text" />
            <InputForm class="col-12 col-lg-3" :label="'Estado Civil'" type="text" />
            <InputForm class="col-12 col-lg-3" :label="'Data de Nascimento'" type="data" />
            <InputForm class="col-12 col-lg-3" :label="'Apelido'" type="text" />
          </div>
          <div class="info mt-4">
            <span>Dados Complementares</span>
          </div>
          <div class="d-flex row col-12 col-md-12 col-lg-12">
            <InputForm class="col-12 col-lg-4" :label="'Perfil'" type="text" />
            <InputForm class="col-12 col-lg-4" :label="'Função'" type="text" />
            <InputForm class="col-12 col-lg-4" :label="'Naturalidade'" type="data" />
            <InputForm class="col-12 col-lg-6" :label="'Chave Pix'" type="text" />
          </div>
          <div class="info mt-4">
            <span>Horário de Trabalho</span>
          </div>
          <div class="d-flex justify-content-between row col-12 col-md-12 col-lg-12">
            <div class="col-lg-5 row">
              <h5 class="mt-3">Dias da semana</h5>
              <InputForm class="col-6" :label="'Início'" type="text" />
              <InputForm class="col-6" :label="'Fim'" type="text" />
            </div>
            <div class="col-lg-5 row">
              <h5 class="mt-3">Sábado</h5>
              <InputForm class="col-6" :label="'Início'" type="text" />
              <InputForm class="col-6" :label="'Fim'" type="text" />
            </div>
          </div>

          <div class="info mt-4">
            <span>Documentos</span>
          </div>
          <div class="d-flex row col-12 col-md-12 col-lg-12">
            <InputForm class="col-12 col-lg-4" :label="'Número identidade'" type="text" />
            <InputForm class="col-12 col-lg-4" :label="'Orgão Emissor identidade'" type="text" />
            <InputForm class="col-12 col-lg-4" :label="'UF identidade'" type="data" />
            <InputForm class="col-12 col-lg-4" :label="'Título de eleitor'" type="text" />
            <InputForm class="col-12 col-lg-4" :label="'Seção título'" type="text" />
            <InputForm class="col-12 col-lg-4" :label="'Zona do título'" type="text" />
            <InputForm class="col-12 col-lg-3" :label="'Carteira de trabalho'" type="text" />
            <InputForm class="col-12 col-lg-3" :label="'Série carteira'" type="text" />
            <InputForm class="col-12 col-lg-3" :label="'Data de emissão carteira'" type="text" />
            <InputForm class="col-12 col-lg-3" :label="'UF da carteira'" type="text" />
          </div>

          <div class="info mt-4">
            <span>Endereço</span>
          </div>
          <div class="d-flex row col-12 col-md-12 col-lg-12">
            <InputForm class="col-12 col-lg-4" :label="'CEP'" type="text" />
            <div class="col-lg-8 d-flex align-items-end"><a class="d-flex align-items-bottom">maps</a></div>
            <InputForm class="col-12 col-lg-9" :label="'Logradouro'" type="text" />
            <InputForm class="col-12 col-lg-3" :label="'Número'" type="data" />
            <InputForm class="col-12 col-lg-2" :label="'Estado'" type="text" />
            <InputForm class="col-12 col-lg-5" :label="'Cidade'" type="text" />
            <InputForm class="col-12 col-lg-5" :label="'Bairro'" type="text" />
            <InputForm class="col-12 col-lg-6" :label="'Referência'" type="text" />
            <InputForm class="col-12 col-lg-6" :label="'Complemento'" type="text" />
          </div>

          <div class="info mt-4">
            <span>Contato</span>
          </div>
          <div class="d-flex row col-12 col-md-12 col-lg-12">
            <InputForm class="col-12 col-lg-6" :label="'Telefone'" type="text" />
            <InputForm class="col-12 col-lg-6" :label="'E-mail'" type="data" />
          </div>

        </div>
      </form>
      <template #footer>
        <div class="d-flex justify-content-end p-3">
          <button class="btn btn-secondary mx-2" @click="visible = false" autofocus>Cancelar</button>
          <button class="btn btn-primary" @click="visible = false" autofocus>Salvar</button>
        </div>
      </template>
    </DialogBox>
  </div>
</template>

<script setup>
import { ref } from "vue";

const visible = ref(true);
</script>

<script>

import InputForm from "@/components/input/input.vue";

export default {
  name: "UsuariosV",
  components: {
    InputForm,
  },
  data() {
    return {
      showModal: false,
      users: [],
      newUserName: "",
    };
  },
  methods: {
    openModal() {
      this.showModal = true;
    },
    closeModal() {
      this.showModal = false;
    },
  },
};
</script>
<style>
@import "./usuarios.css";
@import "../../App.css";
</style>
