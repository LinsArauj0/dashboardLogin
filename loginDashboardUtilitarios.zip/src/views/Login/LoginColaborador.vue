<template>
  <div class="container">
    <div class="left-column">
      <img src="../../assets/imageLeftLogin.png" alt="image de fundo azul" />
    </div>
    <div class="right-column">
      <div class="form-content">
        <h2>Login</h2>
        <form @submit.prevent="login">
          <div class="div-input">
            <label for="email">Email</label><br />
            <input
              type="text"
              id="email"
              v-model="credenciais.username"
              required
              autocomplete="username"
            />
          </div>
          <div class="div-input">
            <label for="password">Senha</label><br />
            <input
              type="password"
              id="password"
              v-model="credenciais.password"
              required
              autocomplete="current-password"
            />
          </div>

          <div class="submit">
            <div>
              <a href="#">Esqueceu a senha?</a>
            </div>
            <div>
              <button class="btn-login" type="submit">Entrar</button>
            </div>
          </div>
        </form>
        <div v-if="loading" class="loading-indicator"></div>
        <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
      </div>
      <div class="bottom-column">
        <img src="../../assets/imageBottomLogin.png" />
      </div>
    </div>
  </div>
</template>

<script>
import LoginService from "@/service/resource/loginService";

export default {
  name: "LoginColaborador",
  data() {
    return {
      //Criei um objeto para credenciais
      credenciais: {
        username: "",
        password: "",
      },
      errorMessage: "",
      loading: false,
    };
  },
  methods: {
    async login() {
      const loginService = new LoginService(); //Instancia de LoginService
      this.loading = true;

      try {
        const response = await loginService.loginColaborador(this.credenciais); //Executa o método loginColaborador dentro de Login Service

        if (response.data && response.data.token) {
          localStorage.setItem("Token", response.data.token);
          this.$router.push("/utilitarios");
        } else {
          this.errorMessage = "Credenciais inválidas. Por favor, tente novamente.";
        }
      } catch (error) {
        console.error("Erro ao fazer login:", error);
        this.errorMessage =
          "Ocorreu um erro ao processar sua solicitação. Por favor, tente novamente mais tarde.";
      }
    },
  },
};
</script>

<style>
@import "./login.css";
</style>
