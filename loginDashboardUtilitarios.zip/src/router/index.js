import { createRouter, createWebHashHistory } from 'vue-router'
import LoginScreen from '../views/Login/LoginColaborador.vue'
import Utilitarios from '@/views/Utiliario/Utilitarios.vue'
import Usuarios from '@/views/Usuarios/Usuarios.vue'
import Navbar from '@/components/NavBar/Navbar.vue'
import authGuard from '@/auth/authGuard'

const routes = [
  {
    path: '/',
    name: 'Login',
    component: LoginScreen
  },
  {
    path:'/utilitarios',
    name: 'Utilitarios',
    component: Utilitarios,
    beforeEnter: authGuard
  },
  {
    path:"/usuarios",
    name: 'Usuarios',
    component: Usuarios,
    beforeEnter: authGuard
  },
  {
    path: "/navbar",
    name: "Navbar",
    component: Navbar,
    beforeEnter: authGuard
  },
  
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
